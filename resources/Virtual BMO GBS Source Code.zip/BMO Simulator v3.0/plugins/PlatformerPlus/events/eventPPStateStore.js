const id = "PM_EVENT_PLATPLUS_STATE_STORE";
const groups = ["Platformer+", "Player Fields", "EVENT_GROUP_VARIABLES"];
const name = "Store Platformer+ State In a Variable";

const fields = [
  {
    label: "Gets player state and stores it in a variable."
  },
  {
    key: "variable",
    type: "variable",
    defaultValue: "LAST_VARIABLE",
  },
  {
    key: "field",
    defaultValue: "plat_state",
  },
  {
    label: "0 = Neutral, 1 = Grounded, 2 = Jumping, 3 = Dashing, 4 = On a Ladder, 5 = On a Wall",
  },

  
];

const compile = (input, helpers) => {
  const { appendRaw, getVariableAlias, _addComment } = helpers;
  const fieldVarTypeLookup = {
    plat_state: "UINT8",
  };
  const fieldName = `_${input.field}`;
  const variableAlias = getVariableAlias(input.variable);

  _addComment("Store player field in variable");
  appendRaw(
    `VM_GET_${fieldVarTypeLookup[input.field]} ${variableAlias}, ${fieldName}`
  );
};

module.exports = {
  id,
  name,
  groups,
  fields,
  compile,
  allowedBeforeInitFade: true,
};
