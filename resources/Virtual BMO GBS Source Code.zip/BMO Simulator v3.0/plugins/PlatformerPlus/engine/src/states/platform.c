/*
Future notes on things to do:
- Limit air dashes before touching the ground
- write event plugin for dash_interrupt
    - Test this for the specific dash problem of being pushed into walls
- Write an event plugin for the state machine
- Add an option for wall jump that only allows alternating walls.

OTHER NOTES
- 256 velocities per position, 16 'positions' per pixel, 8 pixels per tile

//Some ways to reduce variable use: no-control can be a single var w/ multiple numeric states.
//Can probably get rid of col_left and col_right and just use last_wall, or at least reduce them to a single state. If the latter, it can also be local to update
//Can I get away with switching words to bytes for distance, and simultaneously reducing vel to position?
//Switch dash_ready and dash_current frame to a single (signed) value

//Steps before uploading to Github
//1. Comment better
//2. Turn it into a true state machine
//3. Pull out and abstract collision code
//4. Pull out functions for different acceleration types


ARCHITECTURE
OnLadder Movement
    Input (probably move this above ladder stuff...)
        Double-Tap Check
    Calculate Horizontal Movement
        Dashing (collision checks for clear landing)
        Walking/Running (accel and decel)
        Moving Platforms
    Calculate Vertical Movement (move up before step X)
        Move onto ladders
        Gravity
        Moving Platforms
    Step X
        Dash Collision Checks
        Normal Collision Checks
        Update Wall State

        Wall-State Check 
    Step Y 
        Falling
            Drop through floors
        Hitting the ceiling
        Clamp velocity
Check for Triggers at Position
Check for Actors at Position
    Attach to a moving Platform
Jump Input (excute next frame). What is the logic for having this here and not in the vertical movement calc? 
    Wall Jump
    Coyote Time
    Double Jump
    Buffered Jump
Jumping State Logic
Counters
Update Player Animation/Direction
*/
#pragma bank 3

#include "data/states_defines.h"
#include "states/platform.h"

#include "actor.h"
#include "camera.h"
#include "collision.h"
#include "data_manager.h"
#include "game_time.h"
#include "input.h"
#include "math.h"
#include "scroll.h"
#include "trigger.h"
#include "vm.h"

#ifndef INPUT_PLATFORM_JUMP
#define INPUT_PLATFORM_JUMP        INPUT_A
#endif
#ifndef INPUT_PLATFORM_RUN
#define INPUT_PLATFORM_RUN         INPUT_B
#endif
#ifndef INPUT_PLATFORM_INTERACT
#define INPUT_PLATFORM_INTERACT    INPUT_A
#endif
#ifndef PLATFORM_CAMERA_DEADZONE_X
#define PLATFORM_CAMERA_DEADZONE_X 4
#endif
#ifndef PLATFORM_CAMERA_DEADZONE_Y
#define PLATFORM_CAMERA_DEADZONE_Y 16
#endif


//DEFAULT ENGINE VARIABLES
WORD plat_min_vel;
WORD plat_walk_vel;
WORD plat_run_vel;
WORD plat_climb_vel;
WORD plat_walk_acc;
WORD plat_run_acc;
WORD plat_dec;
WORD plat_jump_vel;
WORD plat_grav;
WORD plat_hold_grav;
WORD plat_max_fall_vel;

//PLATFORMER PLUS ENGINE VARIABLES
UBYTE plat_drop_through; //Drop-through control
UBYTE plat_mp_group;
WORD plat_jump_min;
UBYTE plat_hold_jump_max; //Maximum number for frames for continuous input
UBYTE plat_extra_jumps; //Number of jumps while in the air
WORD plat_jump_reduction; //Reduce height each double jump
UBYTE plat_coyote_max; //Coyote Time maximum frames
UBYTE plat_buffer_max; //Jump Buffer maximum frames
UBYTE plat_wall_jump_max; //Number of wall jumps in a row
UBYTE plat_wall_slide;
WORD plat_wall_grav; //Gravity while clinging to the wall
WORD plat_wall_kick;
UBYTE plat_float_input;
WORD plat_float_grav;
UBYTE plat_air_control;
WORD plat_air_dec; // air deceleration rate
UBYTE plat_run_type;
WORD plat_run_boost;
UBYTE plat_dash;
UBYTE plat_dash_style;
UBYTE plat_dash_momentum;
UBYTE plat_dash_through;
WORD plat_dash_dist;
UBYTE plat_dash_frames;
UBYTE plat_dash_ready_max;

enum pStates {
    NEUTRAL_STATE = 0,
    GROUND_STATE,
    JUMP_STATE,
    DASH_STATE,
    LADDER_STATE,
    WALL_STATE,
    FALL_STATE
}; 
enum pStates plat_state;

UBYTE nocontrol_h; 
UBYTE nocontrol_v;
UBYTE nocollide;

//COUNTER variables
UBYTE ct_val; //Coyote Time Variable
UBYTE jb_val; //Jump Buffer Variable
UBYTE wc_val; //Wall Coyote Time Variable
UBYTE plat_hold_jump_val; //Jump input hold variable
UBYTE dj_val; //Current double jump
UBYTE wj_val; //Current wall jump

//WALL variables -- these might be simplified
UBYTE col_left; //tracks if there is a block left or right
UBYTE col_right; 
BYTE last_wall; //tracks the last wall the player touched

//DASH VARIABLES
UBYTE dash_ready_val;
WORD dash_dist;
UBYTE plat_dash_currentframe;
BYTE tap_val;
BYTE dash_dir;
UBYTE dash_end_clear;

//PLATFORM VARS
actor_t *last_mp;
UBYTE mp_attached;
WORD mp_last_x;
WORD mp_last_y;

//JUMPING VARIABLES
WORD plat_jump_reduction_val; //Holds a temporary jump velocity reduction
WORD plat_jump_val;
WORD jump_reduction;

//WALKING AND RUNNING VARIABLES
WORD pl_vel_x;
WORD pl_vel_y;

//VARIABLES FOR EVENT PLUGINS
UBYTE grounded;
UBYTE run_stage;
UBYTE dash_interrupt;




void platform_init() BANKED {
    //Make sure jumping doesn't overflow variables
    //First, check for jumping based on Frames and Initial Jump Min
    while (32000 - (plat_jump_vel/plat_hold_jump_max) - plat_jump_min < 0){
        plat_hold_jump_max += 1;
    }

    //Once that's calibrated, add in a check for Horizontal speed
    while (((32000 - (plat_jump_vel/plat_hold_jump_max) - plat_jump_min) - ((plat_run_vel/(100*plat_hold_jump_max)) * plat_run_boost)) < 0){
        plat_jump_min -= 500;
        plat_run_boost -= 25;
    }

    //Normalize variables by number of frames
    plat_jump_val = plat_jump_vel / plat_hold_jump_max;
    jump_reduction = plat_jump_reduction / plat_hold_jump_max;
    dash_dist = plat_dash_dist/plat_dash_frames;

    if (PLAYER.dir == DIR_UP || PLAYER.dir == DIR_DOWN) {
        PLAYER.dir = DIR_RIGHT;
    }

    if (plat_mp_group == 0){ plat_mp_group = FALSE;}
    else if (plat_mp_group == 2){plat_mp_group = COLLISION_GROUP_1;}
    else if (plat_mp_group == 4){plat_mp_group = COLLISION_GROUP_2;}
    else if (plat_mp_group == 8){plat_mp_group = COLLISION_GROUP_3;}
    mp_attached = FALSE;

    //Initialize State
    plat_state = NEUTRAL_STATE;
    grounded = FALSE;
    run_stage = 0;
    nocontrol_h = 0;
    nocontrol_v = 0;
    nocollide = 0;

    //Initialize other vars
    camera_offset_x = 0;
    camera_offset_y = 0;
    camera_deadzone_x = PLATFORM_CAMERA_DEADZONE_X;
    camera_deadzone_y = PLATFORM_CAMERA_DEADZONE_Y;
    game_time = 0;
    pl_vel_x = 0;
    pl_vel_y = plat_grav << 2;
    last_wall = 0;
    plat_hold_jump_val = plat_hold_jump_max;
    dj_val = 0;
    wj_val = plat_wall_jump_max;
    dash_end_clear = FALSE;
    dash_interrupt = FALSE;

    // If starting tile was a ladder start scene attached to it
    UBYTE tile_x, tile_y;
    tile_x = PLAYER.pos.x >> 7;
    tile_y = PLAYER.pos.y >> 7;
    if (tile_at(tile_x, tile_y - 1) & TILE_PROP_LADDER) {
        // Snap to ladder
        UBYTE p_half_width = (PLAYER.bounds.right - PLAYER.bounds.left) >> 1;
        PLAYER.pos.x = (((tile_x << 3) + 4 - (PLAYER.bounds.left + p_half_width) << 4));
        actor_set_anim(&PLAYER, ANIM_CLIMB);
        actor_stop_anim(&PLAYER);
        plat_state = LADDER_STATE;
    } else {
        //DEBUG
        //on_ladder = FALSE;
        actor_set_anim_idle(&PLAYER);
    }


}

void platform_update() BANKED {
    UBYTE tile_start, tile_end, tile_current;
    actor_t *hit_actor;
    UBYTE p_half_width = (PLAYER.bounds.right - PLAYER.bounds.left) >> 1;
    WORD temp_y = 0;
    WORD deltaX = 0;
    WORD deltaY = 0;
    WORD mid_run = 0;
    if (plat_run_type == 3){
        mid_run = (plat_run_vel - plat_walk_vel)/2;
        mid_run += plat_walk_vel;
    }

    // Ladder Movement=================================================================================================
    if (plat_state == LADDER_STATE) {
        // PLAYER.pos.x = 0;
        UBYTE tile_x_mid = ((PLAYER.pos.x >> 4) + PLAYER.bounds.left + p_half_width) >> 3; 
        pl_vel_y = 0;
        if (INPUT_UP) {
            // Climb laddder
            UBYTE tile_y = ((PLAYER.pos.y >> 4) + PLAYER.bounds.top + 1) >> 3;
            if (tile_at(tile_x_mid, tile_y) & TILE_PROP_LADDER) {
                pl_vel_y = -plat_climb_vel;
            }
        } else if (INPUT_DOWN) {
            // Descend ladder
            UBYTE tile_y = ((PLAYER.pos.y >> 4) + PLAYER.bounds.bottom + 1) >> 3;
            if (tile_at(tile_x_mid, tile_y) & TILE_PROP_LADDER) {
                pl_vel_y = plat_climb_vel;
            }
        } else if (INPUT_LEFT) {
            plat_state = NEUTRAL_STATE;
            // Check if able to leave ladder on left
            tile_start = (((PLAYER.pos.y >> 4) + PLAYER.bounds.top)    >> 3);
            tile_end   = (((PLAYER.pos.y >> 4) + PLAYER.bounds.bottom) >> 3) + 1;
            while (tile_start != tile_end) {
                if (tile_at(tile_x_mid - 1, tile_start) & COLLISION_RIGHT) {
                    plat_state = LADDER_STATE;
                    break;
                }
                tile_start++;
            }            
        } else if (INPUT_RIGHT) {
            plat_state = NEUTRAL_STATE;
            // Check if able to leave ladder on right
            tile_start = (((PLAYER.pos.y >> 4) + PLAYER.bounds.top)    >> 3);
            tile_end   = (((PLAYER.pos.y >> 4) + PLAYER.bounds.bottom) >> 3) + 1;
            while (tile_start != tile_end) {
                if (tile_at(tile_x_mid + 1, tile_start) & COLLISION_LEFT) {
                    plat_state = LADDER_STATE;
                    break;
                }
                tile_start++;
            }
        }
        PLAYER.pos.y += (pl_vel_y >> 8);
    } else {

        //INPUT CHECK=================================================================================================

        //Dash Input Check
        UBYTE dash_press = FALSE;
        if (plat_dash == 1){
            if (INPUT_PRESSED(INPUT_PLATFORM_INTERACT)){
                dash_press = TRUE;
            }
        }
        else if (plat_dash == 2){
            if (INPUT_PRESSED(INPUT_LEFT)){
                if(tap_val < 0){
                    dash_press = TRUE;
                } else{
                    tap_val = -15;
                }
            } else if (INPUT_PRESSED(INPUT_RIGHT)){
                if(tap_val > 0){
                    dash_press = TRUE;
                } else{
                    tap_val = 15;
                }
            }
        }
        else if (plat_dash == 3){
            if ((INPUT_PRESSED(INPUT_DOWN) && INPUT_PLATFORM_JUMP) || (INPUT_DOWN && INPUT_PRESSED(INPUT_PLATFORM_JUMP))){
                dash_press = TRUE;
            }
        }

        //Drop Through Press
        UBYTE drop_press = FALSE;
        if ((plat_drop_through == 1 && INPUT_DOWN ) || (plat_drop_through == 2 && INPUT_DOWN && INPUT_PLATFORM_JUMP)){
            drop_press = TRUE;
        }

        //FLOAT INPUT
        UBYTE float_press = FALSE;
        if ((plat_float_input == 1 && INPUT_PLATFORM_JUMP) || (plat_float_input == 2 && INPUT_UP)){
            float_press = TRUE;
        }

        // Horizontal Movement=========================================================================================
        //1. Dashing---------------------------------------------------------------------------------------------------
        UBYTE dash_start = FALSE;
        //Check for input and if we're already in a dash
        if (plat_state != DASH_STATE && dash_press == TRUE){
            //check for correct dash type
            if((plat_state == GROUND_STATE && plat_dash_style == 0) || (plat_state != GROUND_STATE && plat_dash_style == 1) || plat_dash_style == 2){
                //check for recharge and script interrupt
                if (dash_ready_val == 0 && !dash_interrupt){
                    dash_start = TRUE;
                }
            }
        }

        if(dash_start == TRUE){
            plat_state = DASH_STATE;
            if (INPUT_RIGHT){
                dash_dir = 1;
            }
            else if(INPUT_LEFT){
                dash_dir = -1;
            }
            else if (PLAYER.dir == DIR_LEFT){
                dash_dir = -1;
            }
            else {
                dash_dir = 1;
            }
            //Dash through walls extra checks
            if(plat_dash_through == 3 && plat_dash_momentum < 2){
                dash_end_clear = true;
                tile_start = (((PLAYER.pos.y >> 4) + PLAYER.bounds.top)    >> 3);
                tile_end   = (((PLAYER.pos.y >> 4) + PLAYER.bounds.bottom) >> 3) + 1;        
                WORD new_x = PLAYER.pos.x + (dash_dir*(dash_dist*(plat_dash_frames+1)));

                //Check for a landing spot on the right
                if (dash_dir == 1){
                    if (PLAYER.pos.x + (PLAYER.bounds.right <<4) + (dash_dist*(plat_dash_frames+1)) > (image_width -16) <<4)
                    dash_end_clear = false;
                    else{
                        UBYTE tile_xr = ((new_x >> 4) + PLAYER.bounds.right) >> 3;
                        UBYTE tile_xl = ((new_x >> 4) + PLAYER.bounds.left) >> 3;
                        while (tile_start != tile_end) {
                            if (tile_at(tile_xr, tile_start) & COLLISION_LEFT) {
                                    dash_end_clear = false;
                                    break;
                            }
                            else if (tile_at(tile_xl, tile_start) & COLLISION_RIGHT) {
                                    dash_end_clear = false;
                                    break;
                            }
                            tile_start++;
                        }
                    }
                }
                //Check for a landing spot on the left
                else if(dash_dir == -1) {
                    if (PLAYER.pos.x <= ((dash_dist*(plat_dash_frames+1))+(PLAYER.bounds.left << 4))+(8<<4)){
                        dash_end_clear = false;
                    }
                    else{
                        UBYTE tile_xr = ((new_x >> 4) + PLAYER.bounds.right) >> 3;
                        UBYTE tile_xl = ((new_x >> 4) + PLAYER.bounds.left) >> 3;
                        while (tile_start != tile_end) {
                            if (tile_at(tile_xr, tile_start) & COLLISION_LEFT) {
                                    dash_end_clear = false;
                                    break;
                            }
                            else if (tile_at(tile_xl, tile_start) & COLLISION_RIGHT) {
                                    dash_end_clear = false;
                                    break;
                            }
                            tile_start++;
                        }
                    }
                }
            }
            camera_deadzone_x = 32;
            dash_ready_val = plat_dash_ready_max + plat_dash_frames;
            nocontrol_h = plat_dash_frames;
            if(plat_dash_momentum < 2){
              nocontrol_v = plat_dash_frames;
            }
            plat_dash_currentframe = plat_dash_frames;
            tap_val = 0;
        } else {
            //Dash Interrupt for Editor Event
            if(dash_interrupt){
                dash_dir = 0;
                plat_dash_currentframe = 0;
            }

            //2. Horizontal Accel and Decel -------------------------------------------------------------------------------
            if (nocontrol_h != 0 || plat_state == LADDER_STATE){
                //No horizontal input
                deltaX = pl_vel_x;
            } else if (plat_air_control == 0 && plat_state != GROUND_STATE){
                deltaX = pl_vel_x;
                //No accel or decel in mid-air
            } else if (INPUT_LEFT) {
            //a. Walk and Run 
                    if (INPUT_PLATFORM_RUN) {
                        //Run Type
                        if(plat_run_type == 0){
                        //Smooth
                            pl_vel_x -= plat_run_acc;
                            pl_vel_x = CLAMP(pl_vel_x, -plat_run_vel, -plat_min_vel);
                            deltaX = pl_vel_x;
                            run_stage = 1;
                        } else if (plat_run_type == 1){
                        //Immediate
                            pl_vel_x = -plat_run_vel;
                            deltaX = pl_vel_x;
                            run_stage = 1;
                        } else if (plat_run_type == 2){
                        //Two-Tier
                            if (pl_vel_x > -plat_walk_vel){
                                pl_vel_x -= plat_walk_acc;
                                deltaX = pl_vel_x;
                                run_stage = 1;
                            } else if (pl_vel_x > -plat_run_vel){
                                pl_vel_x -= plat_run_acc;
                                pl_vel_x = CLAMP(pl_vel_x, -plat_run_vel, -plat_min_vel);
                                deltaX = -plat_walk_vel;
                                run_stage = 2;
                        } else{
                                deltaX = -plat_run_vel;
                                run_stage = 3;
                        }
                        } else if (plat_run_type == 3){
                        //Three Tier
                            if (pl_vel_x > -plat_walk_vel){
                                pl_vel_x -= plat_walk_acc;
                                deltaX = pl_vel_x;
                                run_stage = 1;
                            } else if (pl_vel_x > -mid_run){
                                pl_vel_x -= plat_run_acc;
                                deltaX = -plat_walk_vel;
                                run_stage = 2;
                            } else if (pl_vel_x > -plat_run_vel){
                                pl_vel_x -= plat_run_acc;
                                pl_vel_x = CLAMP(pl_vel_x, -plat_run_vel, -plat_min_vel);
                                deltaX = -mid_run;
                                run_stage = 3;
                            } else {
                                deltaX = -plat_run_vel;
                                run_stage = 4;
                            }
                        }
                    } else {
                        //Ordinay Walk
                        run_stage = 0;
                        pl_vel_x -= plat_walk_acc;
                        pl_vel_x = CLAMP(pl_vel_x, -plat_walk_vel, -plat_min_vel);
                        deltaX = pl_vel_x;
                    }
            } else if (INPUT_RIGHT) {
                    if (INPUT_PLATFORM_RUN) {
                        //Run Type
                        if(plat_run_type == 0){
                        //Smooth
                            pl_vel_x += plat_run_acc;
                            pl_vel_x = CLAMP(pl_vel_x, plat_min_vel, plat_run_vel);
                            run_stage = 1;
                            deltaX = pl_vel_x;
                        } else if (plat_run_type == 1){
                        //Immediate
                            run_stage = 1;
                            pl_vel_x = plat_run_vel;
                            deltaX = pl_vel_x;
                        } else if (plat_run_type == 2){
                        //Two Tier
                            if (pl_vel_x < plat_walk_vel){
                                pl_vel_x += plat_walk_acc;
                                deltaX = pl_vel_x;
                                run_stage = 1;
                            } else if (pl_vel_x < plat_run_vel){
                                pl_vel_x += plat_run_acc;
                                pl_vel_x = CLAMP(pl_vel_x, plat_min_vel, plat_run_vel);
                                run_stage = 2;
                                deltaX = plat_walk_vel;
                        } else{
                                run_stage = 3;
                                deltaX = plat_run_vel;
                        }
                        } else if (plat_run_type == 3){
                        //Three Tier
                            if (pl_vel_x < plat_walk_vel){
                                pl_vel_x += plat_walk_acc;
                                run_stage = 1;
                                deltaX = pl_vel_x;
                            } else if (pl_vel_x < mid_run){
                                pl_vel_x += plat_run_acc;
                                run_stage = 2;
                                deltaX = plat_walk_vel;
                            } else if (pl_vel_x < (plat_run_vel)){
                                pl_vel_x += plat_run_acc;
                                pl_vel_x = CLAMP(pl_vel_x, plat_min_vel, plat_run_vel);
                                run_stage = 3;
                                deltaX = mid_run;
                            } else {
                                run_stage = 4;
                                deltaX = plat_run_vel;
                            }
                        }
                    } else {
                        //Ordinary Walk
                        run_stage = 0;
                        pl_vel_x += plat_walk_acc;
                        pl_vel_x = CLAMP(pl_vel_x, plat_min_vel, plat_walk_vel);
                        deltaX = pl_vel_x;
                    }
            } else {
                //b. Deceleration (ground and air)
                if (pl_vel_x < 0) {
                    if (plat_state == GROUND_STATE){
                        pl_vel_x += plat_dec;
                    } else { 
                        pl_vel_x += plat_air_dec;
                    }
                    if (pl_vel_x > 0) {
                        pl_vel_x = 0;
                    }
                } else if (pl_vel_x > 0) {
                    if (plat_state == GROUND_STATE){
                        pl_vel_x -= plat_dec;
                        }
                    else { 
                        pl_vel_x -= plat_air_dec;
                        }
                    if (pl_vel_x < 0) {
                        pl_vel_x = 0;
                    }
                }
                run_stage = 0;
                deltaX = pl_vel_x;
            }

            //3. Add X motion from moving platforms-----------------------------------------------------------------------
            deltaX = deltaX >> 8;
            if (mp_attached){
                //BOUNDS NEED TO BE CONVERTED TO FROM PIXELS TO POSITIONS
                if (PLAYER.pos.x + (PLAYER.bounds.left << 4) > last_mp->pos.x + (last_mp->bounds.right<< 4)) {
                    plat_state = NEUTRAL_STATE;
                    mp_attached = FALSE;
                }
                else if (PLAYER.pos.x + (PLAYER.bounds.right << 4) < last_mp->pos.x + (last_mp->bounds.left << 4)){
                    plat_state = NEUTRAL_STATE;
                    mp_attached = FALSE;
                }
                else{
                    deltaX += (last_mp->pos.x - mp_last_x);
                    mp_last_x = last_mp->pos.x;
                }
            }
            
            // Vertical Movement=========================================================================================
            // 1. Ladder Movement-----------------------------------------------------------------------------------------
            if (INPUT_UP) {
                // Grab upwards ladder
                UBYTE tile_x_mid = ((PLAYER.pos.x >> 4) + PLAYER.bounds.left + p_half_width) >> 3;
                UBYTE tile_y   = (((PLAYER.pos.y >> 4) + PLAYER.bounds.top) >> 3);
                if (tile_at(tile_x_mid, tile_y) & TILE_PROP_LADDER) {
                    PLAYER.pos.x = (((tile_x_mid << 3) + 4 - (PLAYER.bounds.left + p_half_width) << 4));
                    plat_state = LADDER_STATE;
                    pl_vel_x = 0;
                }
            } else if (INPUT_DOWN) {
                // Grab downwards ladder
                UBYTE tile_x_mid = ((PLAYER.pos.x >> 4) + PLAYER.bounds.left + p_half_width) >> 3;
                UBYTE tile_y   = (((PLAYER.pos.y >> 4) + PLAYER.bounds.bottom) >> 3) + 1;
                if (tile_at(tile_x_mid, tile_y) & TILE_PROP_LADDER) {
                    PLAYER.pos.x = (((tile_x_mid << 3) + 4 - (PLAYER.bounds.left + p_half_width) << 4));
                    plat_state = LADDER_STATE;
                    pl_vel_x = 0;
                }
            }

            // 2. Gravity-------------------------------------------------------------------------------------------------
            if ((plat_dash_currentframe !=0 && plat_dash_momentum < 2)|| plat_state == LADDER_STATE || mp_attached){
                pl_vel_y = 0;
            } else if (nocollide != 0){
                pl_vel_y += 2500; //magic number, rough minimum for actually having the player descend through a platform
            } 
            else if (INPUT_PLATFORM_JUMP && pl_vel_y < 0) {
                //Gravity while holding jump
                pl_vel_y += plat_hold_grav;
            } else if(plat_state == WALL_STATE){
                //WALL SLIDE
                if (pl_vel_y < 0){
                    pl_vel_y += plat_grav;
                } else if (plat_wall_slide) {
                    pl_vel_y = plat_wall_grav;
                    }
                else{
                    pl_vel_y += plat_grav;
                }
            }
            else if (float_press && pl_vel_y > 0){
                pl_vel_y = plat_float_grav;
            } else {
                //Normal gravity
                pl_vel_y += plat_grav;
            }

            // 3. Add Y motion from moving platforms---------------------------------------------------------------------
            deltaY = pl_vel_y >> 8;
            if (mp_attached){
                deltaY += last_mp->pos.y - mp_last_y;
                mp_last_y = last_mp->pos.y;
            }
        }

        // Step X=====================================================================================================
        tile_start = (((PLAYER.pos.y >> 4) + PLAYER.bounds.top)    >> 3);
        tile_end   = (((PLAYER.pos.y >> 4) + PLAYER.bounds.bottom) >> 3) + 1;        
        col_left = FALSE;
        col_right = FALSE;
        //Dashing----------------------------------------------------------------------------------------------------
        //Right Dash
        if (dash_dir == 1){
            //Get tile x-coord of player position
            tile_current = ((PLAYER.pos.x >> 4) + PLAYER.bounds.right) >> 3;
            //Get tile x-coord of final position
            UWORD new_x = PLAYER.pos.x + (dash_dist);
            UBYTE tile_x = (((new_x >> 4) + PLAYER.bounds.right) >> 3) + 1;
            //CHECK EACH SPACE FROM START TO END
            while (tile_current != tile_x){
                //CHECK TOP AND BOTTOM
                while (tile_start != tile_end) {
                    //Check for Collisions
                    if(plat_dash_through != 3 || dash_end_clear == FALSE){ //If you collide with walls
                        if (tile_at(tile_current, tile_start) & COLLISION_LEFT) {
                            new_x = ((((tile_current) << 3) - PLAYER.bounds.right) << 4) -1;
                            col_right = TRUE;
                            last_wall = -1;
                            wc_val = plat_coyote_max;
                            dash_dir = 0;
                            goto endRcol;
                        }   
                    }
                    //Check for Triggers
                    if (plat_dash_through < 2){
                        if (trigger_at_tile(tile_current, tile_start) != NO_TRIGGER_COLLISON) {
                            new_x = ((((tile_current+1) << 3) - PLAYER.bounds.right) << 4);
                        }
                    }
                    tile_start++;
                }
                tile_start = (((PLAYER.pos.y >> 4) + PLAYER.bounds.top) >> 3);
                tile_current += 1;
            }
            endRcol: 
            if(plat_dash_momentum == 1 || plat_dash_momentum == 3){            
                pl_vel_x = plat_run_vel;
            } else{
                pl_vel_x = 0;
            }
            PLAYER.pos.x = MIN((image_width - 16) << 4, new_x);
        }
        //Left Dash
        else  if (dash_dir == -1){
            //Get tile x-coord of player position
            tile_current = ((PLAYER.pos.x >> 4) + PLAYER.bounds.left) >> 3;
            //Get tile x-coord of final position
            WORD new_x = PLAYER.pos.x - (dash_dist);
            UBYTE tile_x = (((new_x >> 4) + PLAYER.bounds.left) >> 3)-1;
            //CHECK EACH SPACE FROM START TO END
            while (tile_current != tile_x){
                //CHECK TOP AND BOTTOM
                while (tile_start != tile_end) {   
                    //check for walls
                    if(plat_dash_through != 3 || dash_end_clear == FALSE){//If you collide with walls
                        if (tile_at(tile_current, tile_start) & COLLISION_RIGHT) {
                            new_x = ((((tile_current + 1) << 3) - PLAYER.bounds.left) << 4)+1;
                            col_left = TRUE;
                            last_wall = 1;
                            dash_dir = 0;
                            wc_val = plat_coyote_max;
                            goto endLcol;
                        }
                    }
                    //Check for triggers
                    if (plat_dash_through  < 2){
                        if (trigger_at_tile(tile_current, tile_start) != NO_TRIGGER_COLLISON) {
                            new_x = ((((tile_current - 1) << 3) - PLAYER.bounds.left) << 4);
                            goto endLcol;
                        }
                    }  
                    tile_start++;
                }
                tile_start = (((PLAYER.pos.y >> 4) + PLAYER.bounds.top) >> 3);
                tile_current -= 1;
            }
            endLcol: 
            if(plat_dash_momentum == 1 || plat_dash_momentum == 3){            
                pl_vel_x = -plat_run_vel;
            } else{
                pl_vel_x = 0;
            }
            PLAYER.pos.x = MAX(0, new_x);
        }

        //Normal Collision--------------------------------------------------------------------------------------------
        else if (deltaX > 0) {
            //GIVES X POSITION in SUBPIXELS
            UWORD new_x = PLAYER.pos.x + deltaX;
            //GIVES X POSITION IN TILES? OR ACTOR UNITS? IE. 16 pxls
            UBYTE tile_x = ((new_x >> 4) + PLAYER.bounds.right) >> 3;
            while (tile_start != tile_end) {
                if (tile_at(tile_x, tile_start) & COLLISION_LEFT) {
                    new_x = (((tile_x << 3) - PLAYER.bounds.right) << 4) - 1;
                    pl_vel_x = 0;
                    col_left = TRUE;
                    last_wall = 1;
                    wc_val = plat_coyote_max;
                    break;
                }
                tile_start++;
            }
            PLAYER.pos.x = MIN((image_width - 16) << 4, new_x);
        } else if (deltaX < 0) {
            WORD new_x = PLAYER.pos.x + deltaX;
            UBYTE tile_x = ((new_x >> 4) + PLAYER.bounds.left) >> 3;
            while (tile_start != tile_end) {
                if (tile_at(tile_x, tile_start) & COLLISION_RIGHT) {
                    new_x = ((((tile_x + 1) << 3) - PLAYER.bounds.left) << 4) + 1;
                    pl_vel_x = 0;
                    col_right = TRUE;
                    last_wall = -1;
                    wc_val = plat_coyote_max;
                    break;
                }
                tile_start++;
            }
            PLAYER.pos.x = MAX(0, new_x);
        }

        // Step Y=====================================================================================================
        if (plat_state == GROUND_STATE){plat_state = NEUTRAL_STATE;}
        temp_y = PLAYER.pos.y;    
        tile_start = (((PLAYER.pos.x >> 4) + PLAYER.bounds.left)  >> 3);
        tile_end   = (((PLAYER.pos.x >> 4) + PLAYER.bounds.right) >> 3) + 1;
        if (deltaY > 0) {
            //Moving Downward
            WORD new_y = PLAYER.pos.y + deltaY;
            UBYTE tile_yz = ((new_y >> 4) + PLAYER.bounds.bottom) >> 3;
            if (nocollide == 0){
                while (tile_start != tile_end) {
                    if (tile_at(tile_start, tile_yz) & COLLISION_TOP) {
                        //Drop-Through Floor Check 
                        UBYTE drop_attempt = FALSE;
                        if (drop_press == TRUE){
                            drop_attempt = TRUE;
                            while (tile_start != tile_end) {
                                if (tile_at(tile_start, tile_yz) & COLLISION_BOTTOM){
                                    drop_attempt = FALSE;
                                    break;
                                }
                            tile_start++;
                            }
                        }
                        if (drop_attempt == TRUE){
                            nocollide = 5;
                            pl_vel_y += plat_grav; 
                        } else {
                            //Land on Floor
                            new_y = ((((tile_yz) << 3) - PLAYER.bounds.bottom) << 4) - 1;
                            mp_attached = FALSE; //Detach when MP moves through a solid tile.
                            plat_state = GROUND_STATE;
                            pl_vel_y = 0;
                            //Various things that reset when Grounded
                            ct_val = plat_coyote_max; 
                            dj_val = plat_extra_jumps; 
                            wj_val = plat_wall_jump_max;
                            plat_jump_reduction_val = 0;
                            break;
                        }
                    }
                    tile_start++;
                }
            }
            PLAYER.pos.y = new_y;
        } else if (deltaY < 0) {
            //Moving Upward
            WORD new_y = PLAYER.pos.y + deltaY;
            UBYTE tile_yz = (((new_y >> 4) + PLAYER.bounds.top) >> 3);
            while (tile_start != tile_end) {
                if (tile_at(tile_start, tile_yz) & COLLISION_BOTTOM) {
                    new_y = ((((UBYTE)(tile_yz + 1) << 3) - PLAYER.bounds.top) << 4) + 1;
                    pl_vel_y = 0;
                    //MP Test: Attempting stuff to stop the player from continuing upward
                    if(mp_attached){
                        mp_attached = FALSE;
                        temp_y = last_mp->pos.y;
                        new_y = last_mp->pos.y;
                    }
                    break;
                }
                tile_start++;
            }
            PLAYER.pos.y = new_y;
        }
        else if (mp_attached){
            plat_state = GROUND_STATE;
            PLAYER.pos.y += deltaY;
        }
        // Clamp Y Velocity
        pl_vel_y = CLAMP(pl_vel_y,-plat_max_fall_vel, plat_max_fall_vel);
    }

    //Wall-State Check
    if(plat_state != GROUND_STATE && pl_vel_y >= 0 && plat_wall_slide){
        if ((col_right && INPUT_LEFT) || (col_left && INPUT_RIGHT)){
            plat_state = WALL_STATE;
        } else if (plat_state == WALL_STATE) {
            plat_state = NEUTRAL_STATE;
        }
    }

    //Ground Player when on MP  
    if (mp_attached){
        if(last_mp->disabled == TRUE){
            mp_attached = FALSE;
        }
        else{
            plat_state = GROUND_STATE;
        }

    }

    // Check for trigger collisions
    if(plat_state != DASH_STATE || plat_dash_through < 2){
        if (trigger_activate_at_intersection(&PLAYER.bounds, &PLAYER.pos, INPUT_UP_PRESSED)) {
            // Landed on a trigger
            return;
        }
    }

    //Don't hit actors while dashing
    UBYTE can_jump = TRUE;
    if(plat_state != DASH_STATE || plat_dash_through == 0){
        //Actor Collisions
        //Q: Does this only ever return a single actor?
        hit_actor = actor_overlapping_player(FALSE);
        if (hit_actor != NULL && hit_actor->collision_group) {
            //Moving Platform
            if(!mp_attached){
            //Only Attach from Above
                if (temp_y < hit_actor->pos.y + (hit_actor->bounds.top << 4) && pl_vel_y >= 0){
                    if(hit_actor->collision_group == plat_mp_group){
                            //Attach to MP
                            last_mp = hit_actor;
                            mp_last_x = hit_actor->pos.x;
                            mp_last_y = hit_actor->pos.y;
                            PLAYER.pos.y = hit_actor->pos.y + (hit_actor->bounds.top << 4) - (PLAYER.bounds.bottom << 4);
                            //Other cleanup
                            pl_vel_y = 0;
                            mp_attached = TRUE;                        
                            plat_state = GROUND_STATE;
                            ct_val = plat_coyote_max; 
                            dj_val = plat_extra_jumps; 
                            wj_val = plat_wall_jump_max;
                            plat_jump_reduction_val = 0;
                    }
                }
            }
            //All Other Collisions
            player_register_collision_with(hit_actor);
        } else if (INPUT_PRESSED(INPUT_PLATFORM_INTERACT)) {
            if (!hit_actor) {
                hit_actor = actor_in_front_of_player(8, TRUE);
            }
            if (hit_actor && !hit_actor->collision_group && hit_actor->script.bank) {
                script_execute(hit_actor->script.bank, hit_actor->script.ptr, 0, 1, 0);
                can_jump = FALSE;
            }
        }
    }

    //Jump Check
    if (nocontrol_v !=0){
        //Do Nothing
    }
    else if (INPUT_PRESSED(INPUT_PLATFORM_JUMP)){
        if(plat_state != GROUND_STATE){
            //Wall Jump
            if(col_left || col_right || wc_val != 0){
                if(wj_val != 0){
                    if(plat_state != GROUND_STATE){wj_val -= 1;}
                        plat_state = JUMP_STATE;
                        nocontrol_h = 3;
                    if (last_wall == 1){
                        pl_vel_x -= plat_wall_kick + plat_walk_vel;
                    }
                    else if (last_wall == -1){
                        pl_vel_x += plat_wall_kick + plat_walk_vel;
                    }
                }
            }
            if (ct_val != 0){
            //Coyote Time Jump
                plat_state = JUMP_STATE;
            } else if (dj_val != 0){
            //Double Jump
                dj_val -= 1;
                plat_jump_reduction_val += jump_reduction;
                plat_state = JUMP_STATE;
            } else {
            // Setting the Jump Buffer when jump is pressed while not on the ground
            jb_val = plat_buffer_max; 
            }
        
        } else if (can_jump){
        //Standard Jump
            plat_state = JUMP_STATE;
        }
    } else if (jb_val !=0){
        //Jump Buffered Jump
        if (plat_state == GROUND_STATE && can_jump){
            plat_state = JUMP_STATE;
        }
    }

    //STATES
    //JUMPING STATE Counting down frames of jump propulsion
    if (plat_state == JUMP_STATE){
        mp_attached = FALSE;
        //FIRST FRAME
        if (plat_hold_jump_val == plat_hold_jump_max){
            pl_vel_y = -plat_jump_min;
            //Speed*Jump Mulitplier

            jb_val = 0;
		    ct_val = 0;
        }
        //FIRST & SUBSEQUENT FRAMES 
       if (plat_hold_jump_val !=0 && INPUT_PLATFORM_JUMP){
            pl_vel_y -= plat_jump_val;
            //Reduce subsequent jump amounts
            if (plat_jump_vel >= plat_jump_reduction_val){
                pl_vel_y += plat_jump_reduction_val;
            }
            else {
                pl_vel_y = 0;
            }
            if (pl_vel_x > 0){
                pl_vel_y -= (pl_vel_x/(100*plat_hold_jump_max))*plat_run_boost;
            }
            else if (pl_vel_x < 0){
                pl_vel_y += (pl_vel_x/(100*plat_hold_jump_max))*plat_run_boost;
            }
            plat_hold_jump_val -=1;
        } else {
            plat_state = NEUTRAL_STATE;

        }
    }
    else{
        plat_hold_jump_val = plat_hold_jump_max;
    }

    //For compatability with mods that check 'grounded'
    if(plat_state == GROUND_STATE){
        grounded = true;
    } else{
        grounded = false;
    }

    // Counting Down Dash Frames
        if (plat_dash_currentframe == 0){
            dash_dir = 0;
            if (plat_state == DASH_STATE){
                plat_state = NEUTRAL_STATE;
            }
        }
        else {
            plat_dash_currentframe -=1;
        }

	// Counting down Jump Buffer Window
	if (jb_val != 0){
		jb_val -= 1;
	}
	
	// Counting down Coyote Time Window
	if (ct_val != 0){
		ct_val -= 1;
	}
    //Counting down Wall Coyote Time
    if (wc_val !=0 && !col_left && !col_right){
        wc_val -= 1;
    }

    // Counting down No Control frames
    if (nocontrol_h != 0){
        nocontrol_h -= 1;
    }
    if (nocontrol_v != 0){
        nocontrol_v -= 1;
    }
    if (nocollide != 0){
        nocollide -= 1;
    }
    if (dash_ready_val != 0){
        dash_ready_val -=1;
    }
    if (tap_val > 0){
        tap_val -= 1;
    } else if (tap_val < 0){
        tap_val += 1;
    }

    //Hone Camera
    if (camera_deadzone_x > PLATFORM_CAMERA_DEADZONE_X){
        camera_deadzone_x -= 1;
    }


    // Player animation
    if (plat_state == LADDER_STATE) {
        actor_set_anim(&PLAYER, ANIM_CLIMB);
        if (pl_vel_y == 0) {
            actor_stop_anim(&PLAYER);
        }
    } else if (plat_state == GROUND_STATE) {
        if (pl_vel_x < 0) {
            actor_set_dir(&PLAYER, DIR_LEFT, TRUE);
        } else if (pl_vel_x > 0) {
            actor_set_dir(&PLAYER, DIR_RIGHT, TRUE);
        } else {
            actor_set_anim_idle(&PLAYER);
        }
    } else if (plat_state == WALL_STATE) {
    //Face away from walls
        if (col_right){
            actor_set_dir(&PLAYER, DIR_RIGHT, TRUE);
            //actor_set_anim(&PLAYER, ANIM_JUMP_RIGHT);
        } else if (col_left){
            actor_set_dir(&PLAYER, DIR_LEFT, TRUE);
            //actor_set_anim(&PLAYER, ANIM_JUMP_LEFT);
    //Flip in the air
        } 
    }
    else{
        //Other states
        if (pl_vel_x < 0 && PLAYER.dir != DIR_LEFT) {
            actor_set_dir(&PLAYER, DIR_LEFT, TRUE);
        } else if (pl_vel_x > 0 && PLAYER.dir != DIR_RIGHT) {
            actor_set_dir(&PLAYER, DIR_RIGHT, TRUE);
        } 
        if (PLAYER.dir == DIR_LEFT){
            actor_set_anim(&PLAYER, ANIM_JUMP_LEFT);
        } else {
            actor_set_anim(&PLAYER, ANIM_JUMP_RIGHT);
        }
    } 
}
